package net.mooctest;

import static org.junit.Assert.*;

import org.junit.Test;

public class ScheduleTest {

	@Test
	public void test() {
		new Schedule();
	}

}
