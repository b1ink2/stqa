package net.mooctest;

import org.junit.Test;
import org.junit.runner.RunWith;

public class DecodedStringatIndexTest {

  @Test(timeout = 4000)
  public void test0() {
      new DecodedStringatIndex().decodeAtIndex("0", 1);
  }

}
