package net.mooctest;

import org.junit.Test;
import org.junit.runner.RunWith;

public class DivideTwoIntegersTest {
  @Test
  public void test() {
      new DivideTwoIntegers().divide(0, 1);
  }

}
