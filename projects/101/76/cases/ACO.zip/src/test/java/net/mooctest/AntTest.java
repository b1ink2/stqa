package net.mooctest;

import java.util.ArrayList;
import org.junit.Test;
import static org.junit.Assert.*;

public class AntTest {

  @Test(timeout = 4000)
  public void test(){
      ArrayList<String> arrayList0 = new ArrayList<String>();
      Ant ant0 = null;
  }
}
