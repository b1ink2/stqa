package net.mooctest;

import static org.junit.Assert.*;

import org.junit.Test;

public class MSDTest {

	@Test
	public void test() {
		String[] a = {"1"};
		MSD.sort(a);
    }

}
